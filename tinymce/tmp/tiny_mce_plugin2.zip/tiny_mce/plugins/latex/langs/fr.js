// FR lang variables

tinyMCE.addToLang('',{
insert_latex_desc : 'Ins�rer une formule latex',
insert_latex_explain : 'Entrez juste le code mathmode de votre formule latex. Exemple : \\sqrt{a+b} <br /><a href="http://www.forkosh.dreamhost.com/source_mimetexmanual.html#examples" target="_blank">Plus d\'informations</a>',
insert_latex_formula : 'Formule latex',
insert_latex_preview1 : 'Visualisation',
insert_latex_preview2 : 'Visualiser'
});
