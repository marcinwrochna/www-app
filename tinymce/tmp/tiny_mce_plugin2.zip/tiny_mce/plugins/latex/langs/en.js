// UK lang variables

tinyMCE.addToLang('',{
insert_latex_desc : 'Insert latex formula',
insert_latex_explain : 'Enter only your latex mathmode code. Example : \\sqrt{a+b} <br /><a href="http://www.forkosh.dreamhost.com/source_mimetexmanual.html#examples" target="_blank">More informations</a>',
insert_latex_formula : 'Latex formula',
insert_latex_preview1 : 'Preview',
insert_latex_preview2 : 'Preview'
});
